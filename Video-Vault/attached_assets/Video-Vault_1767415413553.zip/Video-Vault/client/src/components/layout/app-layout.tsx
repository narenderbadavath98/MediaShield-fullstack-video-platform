import { ReactNode, useEffect } from "react";
import { Sidebar } from "./sidebar";
import { useStore } from "@/lib/mock-service";
import { useLocation } from "wouter";

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const currentUser = useStore((state) => state.currentUser);
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!currentUser) {
      setLocation("/auth");
    }
  }, [currentUser, setLocation]);

  if (!currentUser) return null;

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="h-full flex flex-col">
          {children}
        </div>
      </main>
    </div>
  );
}
