import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  UploadCloud, 
  Film, 
  Settings, 
  LogOut, 
  Shield 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useStore } from "@/lib/mock-service";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Sidebar() {
  const [location] = useLocation();
  const currentUser = useStore((state) => state.currentUser);
  const logout = useStore((state) => state.logout);

  const navItems = [
    { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/upload", icon: UploadCloud, label: "Upload", roles: ['editor', 'admin'] },
    { href: "/library", icon: Film, label: "Library" },
  ];

  const canSee = (roles?: string[]) => {
    if (!roles) return true;
    return currentUser && roles.includes(currentUser.role);
  };

  return (
    <div className="w-64 h-full border-r border-border bg-sidebar flex flex-col">
      <div className="p-6">
        <div className="flex items-center gap-2 font-heading font-bold text-xl tracking-tight text-white">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Shield className="w-5 h-5 text-white fill-current" />
          </div>
          StreamGuard
        </div>
      </div>

      <div className="px-3 py-2 flex-1 space-y-1">
        {navItems.map((item) => (
          canSee(item.roles) && (
            <Link key={item.href} href={item.href}>
              <a className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                location === item.href 
                  ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-white"
              )}>
                <item.icon className="w-4 h-4" />
                {item.label}
              </a>
            </Link>
          )
        ))}
      </div>

      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-3 mb-4 px-2">
          <Avatar className="w-8 h-8">
            <AvatarImage src={currentUser?.avatar} />
            <AvatarFallback className="text-xs">{currentUser?.username.slice(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{currentUser?.username}</p>
            <p className="text-xs text-muted-foreground capitalize">{currentUser?.role}</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="w-full justify-start text-muted-foreground hover:text-white border-white/10 hover:bg-white/5"
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
