import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, AlertTriangle, ShieldCheck, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import { VideoStatus, SensitivityStatus } from "@/lib/mock-service";

interface StatusBadgeProps {
  status: VideoStatus;
  sensitivity?: SensitivityStatus;
  className?: string;
}

export function StatusBadge({ status, sensitivity, className }: StatusBadgeProps) {
  if (status === 'uploading') {
    return (
      <Badge variant="outline" className={cn("bg-blue-500/10 text-blue-400 border-blue-500/20 gap-1.5", className)}>
        <Loader2 className="w-3 h-3 animate-spin" />
        Uploading
      </Badge>
    );
  }

  if (status === 'processing') {
    return (
      <Badge variant="outline" className={cn("bg-yellow-500/10 text-yellow-400 border-yellow-500/20 gap-1.5", className)}>
        <Loader2 className="w-3 h-3 animate-spin" />
        Processing
      </Badge>
    );
  }

  if (status === 'completed' || status === 'analyzed') {
    if (sensitivity === 'safe') {
      return (
        <Badge variant="outline" className={cn("bg-green-500/10 text-green-400 border-green-500/20 gap-1.5", className)}>
          <ShieldCheck className="w-3 h-3" />
          Safe
        </Badge>
      );
    }
    if (sensitivity === 'flagged') {
      return (
        <Badge variant="outline" className={cn("bg-red-500/10 text-red-400 border-red-500/20 gap-1.5", className)}>
          <ShieldAlert className="w-3 h-3" />
          Flagged
        </Badge>
      );
    }
    // Pending sensitivity but completed processing (rare edge case in mock)
    return (
      <Badge variant="outline" className={cn("bg-gray-500/10 text-gray-400 border-gray-500/20 gap-1.5", className)}>
        <CheckCircle className="w-3 h-3" />
        Ready
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className={cn("bg-destructive/10 text-destructive border-destructive/20 gap-1.5", className)}>
      <AlertTriangle className="w-3 h-3" />
      Error
    </Badge>
  );
}
