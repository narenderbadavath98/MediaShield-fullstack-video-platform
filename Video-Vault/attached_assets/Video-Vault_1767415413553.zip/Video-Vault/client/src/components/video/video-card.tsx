import { Video, useStore } from "@/lib/mock-service";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { StatusBadge } from "./status-badge";
import { Play, MoreVertical, Trash2, Clock, FileVideo } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";

interface VideoCardProps {
  video: Video;
}

export function VideoCard({ video }: VideoCardProps) {
  const [, setLocation] = useLocation();
  const deleteVideo = useStore((state) => state.deleteVideo);
  const currentUser = useStore((state) => state.currentUser);
  
  const isOwner = currentUser?.id === video.uploadedBy;
  const isAdmin = currentUser?.role === 'admin';
  const canManage = isOwner || isAdmin;

  const isPlayable = video.status === 'completed' && video.sensitivity !== 'flagged';

  return (
    <Card className="group overflow-hidden bg-card/50 border-white/5 hover:border-white/10 transition-all duration-300">
      {/* Thumbnail Area */}
      <div className="relative aspect-video bg-black/40 group-hover:bg-black/60 transition-colors">
        {video.thumbnail ? (
          <img 
            src={video.thumbnail} 
            alt={video.title} 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity"
          />
        ) : (
          <div className="flex items-center justify-center w-full h-full text-muted-foreground/30">
            <FileVideo className="w-12 h-12" />
          </div>
        )}

        {/* Overlay Controls */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          {isPlayable && (
            <Button 
              size="icon" 
              variant="secondary" 
              className="rounded-full w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-sm border-0"
              onClick={() => setLocation(`/watch/${video.id}`)}
            >
              <Play className="w-5 h-5 fill-white text-white ml-0.5" />
            </Button>
          )}
        </div>

        {/* Duration Badge */}
        {video.duration && (
          <div className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/70 backdrop-blur-md rounded text-[10px] font-medium text-white">
            {video.duration}
          </div>
        )}
      </div>

      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-1 min-w-0">
            <h3 className="font-medium truncate text-sm leading-tight text-white/90" title={video.title}>
              {video.title}
            </h3>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>{video.size}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDistanceToNow(new Date(video.uploadedAt), { addSuffix: true })}
              </span>
            </div>
          </div>
          
          {canManage && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6 -mr-2 text-muted-foreground hover:text-white">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-32">
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive cursor-pointer"
                  onClick={() => deleteVideo(video.id)}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {/* Progress Bar for Active Uploads */}
        {(video.status === 'uploading' || video.status === 'processing') && (
          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">
              <span>{video.status}</span>
              <span>{Math.round(video.progress)}%</span>
            </div>
            <Progress value={video.progress} className="h-1" />
          </div>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <StatusBadge status={video.status} sensitivity={video.sensitivity} />
      </CardFooter>
    </Card>
  );
}
