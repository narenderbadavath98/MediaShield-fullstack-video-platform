import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';

// --- Types ---

export type UserRole = 'admin' | 'editor' | 'viewer';

export interface User {
  id: string;
  username: string;
  role: UserRole;
  avatar?: string;
}

export type VideoStatus = 'uploading' | 'processing' | 'analyzed' | 'completed' | 'error';
export type SensitivityStatus = 'pending' | 'safe' | 'flagged';

export interface Video {
  id: string;
  title: string;
  filename: string;
  size: string;
  uploadedBy: string; // userId
  uploadedAt: string;
  status: VideoStatus;
  progress: number; // 0-100
  sensitivity: SensitivityStatus;
  thumbnail?: string;
  duration?: string;
  url?: string; // Mock URL for streaming
}

// --- Mock Data ---

const MOCK_USERS: User[] = [
  { id: '1', username: 'admin_user', role: 'admin', avatar: 'https://github.com/shadcn.png' },
  { id: '2', username: 'editor_dave', role: 'editor', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dave' },
  { id: '3', username: 'viewer_alice', role: 'viewer', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alice' },
];

const MOCK_VIDEOS: Video[] = [
  {
    id: 'v1',
    title: 'Product Demo 2024',
    filename: 'demo_final.mp4',
    size: '45 MB',
    uploadedBy: '2',
    uploadedAt: new Date(Date.now() - 86400000).toISOString(),
    status: 'completed',
    progress: 100,
    sensitivity: 'safe',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=60',
    duration: '2:15',
  },
  {
    id: 'v2',
    title: 'User Interview #4',
    filename: 'interview_raw.mov',
    size: '1.2 GB',
    uploadedBy: '2',
    uploadedAt: new Date(Date.now() - 3600000).toISOString(),
    status: 'analyzed',
    progress: 100,
    sensitivity: 'flagged',
    thumbnail: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&auto=format&fit=crop&q=60',
    duration: '45:30',
  },
];

// --- Store ---

interface AppState {
  currentUser: User | null;
  users: User[];
  videos: Video[];
  
  // Actions
  login: (username: string, role: UserRole) => void;
  logout: () => void;
  
  addVideo: (file: File) => Promise<void>;
  updateVideoStatus: (id: string, status: VideoStatus, progress: number, sensitivity?: SensitivityStatus) => void;
  deleteVideo: (id: string) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: MOCK_USERS,
      videos: MOCK_VIDEOS,

      login: (username, role) => {
        const existingUser = get().users.find(u => u.username === username);
        if (existingUser) {
          set({ currentUser: existingUser });
        } else {
          const newUser: User = { 
            id: nanoid(), 
            username, 
            role, 
            avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}` 
          };
          set(state => ({ 
            users: [...state.users, newUser], 
            currentUser: newUser 
          }));
        }
      },

      logout: () => set({ currentUser: null }),

      addVideo: async (file: File) => {
        const user = get().currentUser;
        if (!user) return;

        const newVideo: Video = {
          id: nanoid(),
          title: file.name.split('.')[0],
          filename: file.name,
          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
          uploadedBy: user.id,
          uploadedAt: new Date().toISOString(),
          status: 'uploading',
          progress: 0,
          sensitivity: 'pending',
          thumbnail: '',
          duration: '--:--',
        };

        // FIX: Ensure we append to the existing list using the spread operator
        set(state => ({ videos: [newVideo, ...state.videos] }));

        // Simulate Upload
        await simulateProgress(newVideo.id, 'uploading', 0, 100, 2000);
        
        // Switch to Processing
        get().updateVideoStatus(newVideo.id, 'processing', 0);
        await simulateProgress(newVideo.id, 'processing', 0, 100, 3000);

        // Switch to Analysis
        get().updateVideoStatus(newVideo.id, 'analyzed', 0);
        const sensitivity = Math.random() > 0.8 ? 'flagged' : 'safe';
        
        setTimeout(() => {
            get().updateVideoStatus(newVideo.id, 'completed', 100, sensitivity);
            set(state => ({
                videos: state.videos.map(v => 
                    v.id === newVideo.id 
                    ? { ...v, thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&auto=format&fit=crop&q=60' } 
                    : v
                )
            }));
        }, 1000);
      },

      updateVideoStatus: (id, status, progress, sensitivity) => {
        set(state => ({
          videos: state.videos.map(v => 
            v.id === id 
              ? { ...v, status, progress, ...(sensitivity ? { sensitivity } : {}) }
              : v
          )
        }));
      },

      deleteVideo: (id) => {
        set(state => ({
          videos: state.videos.filter(v => v.id !== id)
        }));
      }
    }),
    {
      name: 'streamguard-storage',
      partialize: (state) => ({ 
        videos: state.videos,
        currentUser: state.currentUser,
        users: state.users
      }),
    }
  )
);

async function simulateProgress(
  videoId: string, 
  status: VideoStatus, 
  start: number, 
  end: number, 
  duration: number
) {
  const steps = 10;
  const interval = duration / steps;
  const increment = (end - start) / steps;

  for (let i = 1; i <= steps; i++) {
    await new Promise(r => setTimeout(r, interval));
    useStore.getState().updateVideoStatus(videoId, status, Math.min(start + (i * increment), 100));
  }
}
