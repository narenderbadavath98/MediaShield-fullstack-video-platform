import { AppLayout } from "@/components/layout/app-layout";
import { useStore } from "@/lib/mock-service";
import { VideoCard } from "@/components/video/video-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, HardDrive, ShieldCheck, ShieldAlert, Users } from "lucide-react";
import { cn } from "@/lib/utils";

export default function DashboardPage() {
  const videos = useStore((state) => state.videos);
  const currentUser = useStore((state) => state.currentUser);

  // Stats
  const totalVideos = videos.length;
  const processing = videos.filter(v => v.status === 'processing' || v.status === 'uploading').length;
  const flagged = videos.filter(v => v.sensitivity === 'flagged').length;
  const safe = videos.filter(v => v.sensitivity === 'safe').length;

  const recentVideos = [...videos].sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()).slice(0, 4);

  return (
    <AppLayout>
      <div className="flex-1 p-8 space-y-8 overflow-y-auto">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Platform overview and real-time processing status.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard 
            title="Total Videos" 
            value={totalVideos} 
            icon={HardDrive} 
            className="border-blue-500/20 bg-blue-500/5 text-blue-500" 
          />
          <StatCard 
            title="Processing" 
            value={processing} 
            icon={Activity} 
            className="border-yellow-500/20 bg-yellow-500/5 text-yellow-500" 
          />
          <StatCard 
            title="Safe Content" 
            value={safe} 
            icon={ShieldCheck} 
            className="border-green-500/20 bg-green-500/5 text-green-500" 
          />
          <StatCard 
            title="Flagged" 
            value={flagged} 
            icon={ShieldAlert} 
            className="border-red-500/20 bg-red-500/5 text-red-500" 
          />
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold tracking-tight">Recent Activity</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentVideos.map(video => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function StatCard({ title, value, icon: Icon, className }: any) {
  return (
    <Card className={cn("border bg-card/50", className)}>
      <CardContent className="p-6 flex items-center justify-between">
        <div className="space-y-1">
          <p className="text-sm font-medium opacity-80">{title}</p>
          <p className="text-3xl font-bold">{value}</p>
        </div>
        <div className="p-3 rounded-full bg-white/10">
          <Icon className="w-6 h-6" />
        </div>
      </CardContent>
    </Card>
  );
}
