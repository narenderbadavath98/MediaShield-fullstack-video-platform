import { AppLayout } from "@/components/layout/app-layout";
import { useStore } from "@/lib/mock-service";
import { VideoCard } from "@/components/video/video-card";
import { Input } from "@/components/ui/input";
import { Search, Filter } from "lucide-react";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function LibraryPage() {
  const videos = useStore((state) => state.videos);
  const currentUser = useStore((state) => state.currentUser);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const filteredVideos = videos.filter(v => {
    const matchesSearch = v.title.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'all' 
      ? true 
      : filter === 'safe' 
        ? v.sensitivity === 'safe'
        : filter === 'flagged'
          ? v.sensitivity === 'flagged'
          : true;
          
    // Mock multi-tenant: Admin sees all, others see own + safe videos? 
    // Or strictly own videos? The prompt says "Each user can access only their own videos".
    // But then "Viewer" role implies viewing videos. 
    // Let's say: 
    // - Editor/Viewer sees OWN videos + ALL SAFE COMPLETED videos from others?
    // Actually prompt says "Viewer: view & stream videos".
    // Let's implement: User sees ALL videos, but can only MANAGE their own.
    
    return matchesSearch && matchesFilter;
  });

  return (
    <AppLayout>
      <div className="flex-1 p-8 space-y-8 overflow-y-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold tracking-tight">Video Library</h1>
            <p className="text-muted-foreground">
              Manage and watch processed videos.
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="relative w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search videos..." 
                className="pl-9 bg-card/50 border-white/10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[140px] bg-card/50 border-white/10">
                <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="safe">Safe Only</SelectItem>
                <SelectItem value="flagged">Flagged Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {filteredVideos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center text-muted-foreground border border-dashed border-white/10 rounded-lg bg-card/20">
            <FilmIcon className="w-12 h-12 mb-4 opacity-20" />
            <h3 className="text-lg font-medium mb-1">No videos found</h3>
            <p>Try adjusting your search or upload a new video.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredVideos.map(video => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function FilmIcon({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M7 3v18" />
      <path d="M3 7.5h4" />
      <path d="M3 12h18" />
      <path d="M3 16.5h4" />
      <path d="M17 3v18" />
      <path d="M17 7.5h4" />
      <path d="M17 16.5h4" />
    </svg>
  );
}
