import { useState } from "react";
import { useStore, UserRole } from "@/lib/mock-service";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, ArrowRight } from "lucide-react";
import stockImage from '@assets/stock_images/abstract_digital_tec_fce9021f.jpg';

export default function AuthPage() {
  const [username, setUsername] = useState("");
  const [role, setRole] = useState<UserRole>("viewer");
  const login = useStore((state) => state.login);
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username) return;
    login(username, role);
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      <div className="relative hidden lg:flex flex-col justify-between p-10 text-white">
        <div className="absolute inset-0 bg-zinc-900">
           <img 
            src={stockImage} 
            alt="Background" 
            className="w-full h-full object-cover opacity-30 mix-blend-overlay"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        </div>
        
        <div className="relative z-10 flex items-center gap-2 font-heading font-bold text-2xl tracking-tight">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Shield className="w-5 h-5 text-white fill-current" />
          </div>
          StreamGuard
        </div>

        <div className="relative z-10 space-y-4">
          <blockquote className="text-lg font-medium leading-relaxed">
            "The most secure and efficient way to manage your video content with automated sensitivity analysis and real-time processing."
          </blockquote>
          <div className="flex gap-2">
            <div className="h-1 w-10 bg-primary rounded-full" />
            <div className="h-1 w-2 bg-white/20 rounded-full" />
            <div className="h-1 w-2 bg-white/20 rounded-full" />
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-8">
        <Card className="w-full max-w-sm border-0 bg-transparent shadow-none">
          <CardHeader className="px-0">
            <CardTitle className="text-2xl font-bold tracking-tight">Welcome back</CardTitle>
            <CardDescription>
              Enter your username to access your account.
              <br />
              (This is a mockup, use any username)
            </CardDescription>
          </CardHeader>
          <CardContent className="px-0">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input 
                  id="username" 
                  placeholder="e.g. editor_dave" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-secondary/50 border-white/10 focus:border-primary/50"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select value={role} onValueChange={(v) => setRole(v as UserRole)}>
                  <SelectTrigger className="bg-secondary/50 border-white/10">
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="viewer">Viewer (Read Only)</SelectItem>
                    <SelectItem value="editor">Editor (Can Upload)</SelectItem>
                    <SelectItem value="admin">Admin (Full Access)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white group">
                Sign In
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>
          </CardContent>
          <CardFooter className="px-0 text-xs text-muted-foreground">
            By clicking continue, you agree to our Terms of Service and Privacy Policy.
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
