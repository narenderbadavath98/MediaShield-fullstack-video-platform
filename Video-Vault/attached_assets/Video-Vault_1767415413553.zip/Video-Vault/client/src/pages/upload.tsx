import { useCallback } from "react";
import { AppLayout } from "@/components/layout/app-layout";
import { useStore } from "@/lib/mock-service";
import { Card, CardContent } from "@/components/ui/card";
import { UploadCloud, FileVideo, X } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function UploadPage() {
  const addVideo = useStore((state) => state.addVideo);
  const currentUser = useStore((state) => state.currentUser);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      acceptedFiles.forEach(file => {
        addVideo(file).then(() => {
          toast({
            title: "Upload Started",
            description: `${file.name} has been added to the processing queue.`,
          });
        });
      });
      setLocation("/library");
    }
  }, [addVideo, setLocation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/mp4': ['.mp4'],
      'video/quicktime': ['.mov']
    },
    maxSize: 500 * 1024 * 1024 // 500MB
  });

  if (currentUser?.role === 'viewer') {
    return (
      <AppLayout>
        <div className="flex-1 flex items-center justify-center p-12 text-center text-muted-foreground">
          You do not have permission to upload videos.
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="flex-1 p-8 max-w-4xl mx-auto w-full space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Upload Video</h1>
          <p className="text-muted-foreground">
            Upload videos for processing and sensitivity analysis. Supported formats: MP4, MOV.
          </p>
        </div>

        <Card className="border-dashed border-2 border-white/10 bg-card/30 hover:bg-card/50 transition-colors">
          <CardContent className="p-0">
            <div 
              {...getRootProps()} 
              className="flex flex-col items-center justify-center min-h-[400px] cursor-pointer"
            >
              <input {...getInputProps()} />
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6 text-primary">
                <UploadCloud className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-medium mb-2">
                {isDragActive ? "Drop the video here" : "Drag & drop video here"}
              </h3>
              <p className="text-sm text-muted-foreground mb-6">
                or click to browse from your computer
              </p>
              <div className="flex gap-4 text-xs text-muted-foreground bg-secondary/50 px-4 py-2 rounded-full border border-white/5">
                <span className="flex items-center gap-1.5">
                  <FileVideo className="w-3.5 h-3.5" />
                  MP4, MOV
                </span>
                <span className="w-px h-4 bg-white/10" />
                <span>Max 500MB</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
