import { AppLayout } from "@/components/layout/app-layout";
import { useStore } from "@/lib/mock-service";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Share2, Flag } from "lucide-react";
import { StatusBadge } from "@/components/video/status-badge";
import { Separator } from "@/components/ui/separator";

export default function WatchPage() {
  const [match, params] = useRoute("/watch/:id");
  const [, setLocation] = useLocation();
  const videos = useStore((state) => state.videos);
  
  const video = videos.find(v => v.id === params?.id);

  if (!video) {
    return (
      <AppLayout>
        <div className="flex-1 flex flex-col items-center justify-center space-y-4">
          <h2 className="text-xl font-medium">Video not found</h2>
          <Button onClick={() => setLocation("/library")}>Return to Library</Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-6xl mx-auto p-6 space-y-6">
          <Button 
            variant="ghost" 
            className="text-muted-foreground hover:text-white pl-0"
            onClick={() => setLocation("/library")}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Library
          </Button>

          <div className="relative aspect-video bg-black rounded-lg overflow-hidden border border-white/10 shadow-2xl">
            {video.sensitivity === 'flagged' ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900 text-center p-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center text-red-500">
                  <Flag className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-medium text-white">Content Warning</h3>
                <p className="text-muted-foreground max-w-md">
                  This video has been flagged by our sensitivity analysis algorithms and is currently locked for viewing.
                </p>
              </div>
            ) : (
              <video 
                controls 
                autoPlay 
                className="w-full h-full"
                poster={video.thumbnail}
                src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
              >
                Your browser does not support the video tag.
              </video>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-2">
                <h1 className="text-2xl font-bold tracking-tight text-white">{video.title}</h1>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <StatusBadge status={video.status} sensitivity={video.sensitivity} />
                  <span>{video.size}</span>
                  <span>•</span>
                  <span>Uploaded {new Date(video.uploadedAt).toLocaleDateString()}</span>
                </div>
              </div>
              
              <div className="flex gap-2">
                 <Button variant="secondary">
                   <Share2 className="w-4 h-4 mr-2" />
                   Share
                 </Button>
              </div>
            </div>

            <Separator className="bg-white/10" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-4">
                <h3 className="font-semibold text-white">Description</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  No description provided for this video.
                  <br /><br />
                  Filename: {video.filename}
                </p>
              </div>
              <div className="space-y-4">
                <h3 className="font-semibold text-white">Analysis Details</h3>
                <div className="bg-card/50 rounded-lg p-4 space-y-3 text-sm border border-white/5">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status</span>
                    <span className="capitalize">{video.status}</span>
                  </div>
                   <div className="flex justify-between">
                    <span className="text-muted-foreground">Sensitivity</span>
                    <span className="capitalize">{video.sensitivity || 'Pending'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Quality</span>
                    <span>1080p</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Format</span>
                    <span className="uppercase">{video.filename.split('.').pop()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
